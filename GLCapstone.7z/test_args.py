import sys,os
IPYNB_FILENAME = 'Capstone_NLP_2.ipynb'
CONFIG_FILENAME = '.config_ipynb'

def main(argv):
    with open(CONFIG_FILENAME,'w') as f:
        f.write(' '.join(argv))
    os.system(
        'jupyter nbconvert --to notebook --ExecutePreprocessor.kernel_name=python3 --ExecutePreprocessor.timeout=3600 --execute Capstone_NLP_2.ipynb'
    )
    # os.system('jupyter nbconvert --execute {:s} --to html'.format(IPYNB_FILENAME))
    # os.system('ipython --TerminalIPythonApp.file_to_run=Capstone_NLP_2.ipynb')
    # jupyter nbconvert --to notebook --ExecutePreprocessor.kernel_name=python3 --ExecutePreprocessor.timeout=3600 --execute Capstone_NLP_2.ipynb
    # papermill EDA.ipynb output.ipynb -p path "D:\codes\GLCapstone\GLCapstone\media\documents\Data_Set_-_industrial_safety_and_health_database_with_accidents_description_U3mCSIV.csv"
    return None

if __name__ == '__main__':
    main(sys.argv)