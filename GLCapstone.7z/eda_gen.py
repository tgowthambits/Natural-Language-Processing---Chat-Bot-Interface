import nbclient
import nbformat
from nbparameterise import (
    extract_parameters, replace_definitions, parameter_values
)

with open("D:\codes\GLCapstone\GLCapstone\Capstone_NLP_2.ipynb",encoding="utf8") as f:
    nb = nbformat.read(f, as_version=4)
    
# Get a list of Parameter objects
orig_parameters = extract_parameters(nb)
print(orig_parameters)
# # Update one or more parameters
# params = parameter_values(orig_parameters, stock='GOOG')

# # Make a notebook object with these definitions
# new_nb = replace_definitions(nb, params)

# # Execute the notebook with the new parameters
# nbclient.execute(new_nb)