from django.db import models
from django.core.files.storage import FileSystemStorage
# Create your models here.
class Csvs(models.Model):
    title = models.CharField(max_length=255, blank=True)
    file = models.FileField(upload_to='csv/')
    uploaded_at = models.DateTimeField(auto_now_add=True)



class Document(models.Model):
    description = models.CharField(max_length=255, blank=True)
    document = models.FileField(upload_to='documents/')
    uploaded_at = models.DateTimeField(auto_now_add=True)


fs = FileSystemStorage(location='/media/cleaned_data')
class CleanedData(models.Model):
    excel_file = models.FileField(storage=fs)
    uploaded_at = models.DateTimeField(auto_now_add=True)

