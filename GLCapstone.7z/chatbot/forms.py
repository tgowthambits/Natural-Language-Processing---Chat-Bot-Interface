from django import forms
from .models import Csvs
from .models import Document



class CsvsForm(forms.ModelForm):
    class Meta:
        model = Csvs
        fields = ('file', )



class DocumentForm(forms.ModelForm):
    class Meta:
        model = Document
        fields = ('description', 'document', )