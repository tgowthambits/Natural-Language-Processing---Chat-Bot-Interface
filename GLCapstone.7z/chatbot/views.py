from django.shortcuts import redirect, render

from django.http import JsonResponse
from django.views import View
from django.views.generic.base import TemplateView

from .forms import CsvsForm, DocumentForm
from .models import Csvs, Document, CleanedData
# Create your views here.
from django.shortcuts import render
from django.conf import settings
from django.core.files.storage import FileSystemStorage
import sys,os
from django.core.files import File
import re
import papermill as pm
from bs4 import BeautifulSoup
from pathlib import Path

BASE_DIR = Path().resolve()

def data_cleaning(request):

    return render(request,template_name='index.html')




def simple_upload(request):
    if request.method == 'POST' and request.FILES['myfile']:
        myfile = request.FILES['myfile']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        uploaded_file_url = fs.url(filename)
        return render(request, 'index.html', {
            'uploaded_file_url': uploaded_file_url
        })

    # return render(request, 'index.html')
    return redirect('run_eda')



def cleanhtml(raw_html):
    with open('C:/Users/SkyNet/Desktop/PyCharmProjects/GLCapstone/chatbot/templates/reports/EDA_output.html', 'r') as page_f:
        soup = BeautifulSoup(page_f.read(), "html.parser")
    cleanr = re.compile('{{sendEvent:t,importSourceUrl:o}}')
    cleantext = re.sub(cleanr, '', raw_html)
    return cleantext




def run_eda(request):
    a = Document.objects.all().latest('id')
    file_name = a.document.name
    print(file_name)
    #    'jupyter nbconvert --to notebook --ExecutePreprocessor.kernel_name=python3 --ExecutePreprocessor.timeout=3600 --execute Capstone_NLP_2.ipynb'
    # os.system(
    #     'papermill EDA.ipynb output.ipynb -p path D:\codes\GLCapstone\GLCapstone\media\documents\Data_Set_-_industrial_safety_and_health_database_with_accidents_description_U3mCSIV.csv'
    # )
    l ='C:/Users/SkyNet/Desktop/PyCharmProjects/GLCapstone/media/'
    p = l+file_name
    print(p)
    pm.execute_notebook(r'C:\Users\SkyNet\Desktop\PyCharmProjects\GLCapstone\EDA.ipynb',
                        r'C:\Users\SkyNet\Desktop\PyCharmProjects\GLCapstone\EDA_output.ipynb',
                        parameters=dict(path=p))
    # os.system('jupyter nbconvert {:s} --to html'format(IPYNB_FILENAME))


    os.system(
        'jupyter nbconvert --output-dir="C:/Users/SkyNet/Desktop/PyCharmProjects/GLCapstone/chatbot/templates/reports"  EDA_output.ipynb --to html'
    )

    layout = CleanedData()
    layout.excel_file = "C:/Users/SkyNet/Desktop/PyCharmProjects/GLCapstone/cleaned_df.csv"
    layout.save()


    return redirect('model_form_upload')
    # return render(request, 'index.html', {
    #     'latest_filename': '[file_name]',

    # })


def model_form_upload(request):
    if request.method == 'POST':
        print(request.FILES)
        form = DocumentForm(request.POST, request.FILES)
        print(request.POST)
        if form.is_valid():
            form.save()
            return redirect('model_form_upload')
    else:
        form = DocumentForm()

    a = Document.objects.all().latest('id')
    file_name = a.document.name

    clean = CleanedData.objects.all().latest('id')
    clean_id = clean.excel_file.name
    print(file_name)
    return render(request, 'index.html', {
        'latest_filename':file_name,
        'form': form,
        'cleaned_file':clean_id
    })




class BasicUploadView(View):
    def get(self, request):
        photos_list = Csvs.objects.all()
        return render(self.request, 'index.html', {'photos': photos_list})

    def post(self, request):
        form = CsvsForm(self.request.POST, self.request.FILES)
        if form.is_valid():
            photo = form.save()
            data = {'is_valid': True, 'name': photo.file.name, 'url': photo.file.url}
        else:
            data = {'is_valid': False}
        return JsonResponse(data)