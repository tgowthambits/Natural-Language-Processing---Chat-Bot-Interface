from django.contrib import admin
from django.urls import path
from .models_train import *
from .prediction import *
urlpatterns = [
    # path('', data_cleaning, name='data_clean'),
    path('GaussianNB/', GaussianNBTrain, name='GaussianNBTrain'),
    path('KNeighborsClassifierTrain/', KNeighborsClassifierTrain, name='KNeighborsClassifierTrain'),
    path('RandomForestClassifierTrain/', RandomForestClassifierTrain, name='RandomForestClassifierTrain'),
    path('prediction_api/', prediction_api, name='prediction_api'),


]
