import json
import re

import joblib
import numpy as np
from django.http import JsonResponse

import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
import os
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk import tokenize,stem



import nltk
nltk.download('stopwords')
from nltk.corpus import stopwords
stopwords=set(stopwords.words('english'))


from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize

nltk.download('wordnet')

def _nlp_preprocess_text(text):
  corpus=[]
  lem=WordNetLemmatizer()
  ignore_words = ['?', '!']
  for news in text:
      words=[w for w in word_tokenize(news) if (w not in ignore_words)]
      words=[lem.lemmatize(w) for w in words if len(w)>2]
      words = sorted(list(set(words)))
      corpus.append(words)
  return corpus

def ngram_func(ngram, trg='', trg_value='',df=None):
    #trg_value is list-object
    if (trg == '') or (trg_value == ''):
        string_filterd =  df['Description_cleaned'].sum().split()
    else:
        string_filterd =  df[df[trg].isin(trg_value)]['Description_cleaned'].sum().split()
    dic = nltk.FreqDist(nltk.ngrams(string_filterd, ngram)).most_common(30)
    ngram_df = pd.DataFrame(dic, columns=['ngram','count'])
    ngram_df.index = [' '.join(i) for i in ngram_df.ngram]
    ngram_df.drop('ngram',axis=1, inplace=True)
    return ngram_df



def prediction_apia(request):
    data = {}
    pred_data = request.GET.get('pred_data',None)
    print(type(pred_data))
    try:
        # d = json.loads(pred_data)
        # print(type(d))
        df = pd.read_json(pred_data,orient='index').T
        df['Date'] = pd.to_datetime(df['Date'])
        df['Year'] = df['Date'].apply(lambda x: x.year)
        df['Month'] = df['Date'].apply(lambda x: x.month)
        df['Day'] = df['Date'].apply(lambda x: x.day)
        df['Weekday'] = df['Date'].apply(lambda x: x.day_name())

        df['Description_cleaned'] = df['Description'].apply(lambda x: re.sub(r'[^A-Za-z]+', ' ', x))
        df['Description_cleaned'] = df['Description_cleaned'].apply(lambda x: x.lower())
        df['Description_cleaned'] = df['Description_cleaned'].apply(
            lambda x: ' '.join([words for words in x.split() if words not in stopwords]))

        corpus = _nlp_preprocess_text(df['Description_cleaned'])
        # print(len(corpus), "unique lemmatized words", corpus)

        feature_df = pd.DataFrame()
        vec_tfidf = TfidfVectorizer(max_features=12, norm='l2', stop_words='english', lowercase=True, use_idf=True,
                                    )
        # X = vec_tfidf.fit_transform(df['Description_cleaned']).toarray()
        X = vec_tfidf.fit(df['Description_cleaned']).toarray()
        print(X)
        tfs = pd.DataFrame(X, columns=["TFIDF_" + n for n in vec_tfidf.get_feature_names()])
        feature_df = pd.concat([feature_df, tfs], axis=1)
        feature_df = pd.concat([df, feature_df], axis=1)
        print(len(feature_df.iloc[0]))
        feature_df['Country'] = LabelEncoder().fit_transform(feature_df['Country']).astype(np.int8)
        feature_df['Local'] = LabelEncoder().fit_transform(feature_df['Local']).astype(np.int8)
        feature_df['IndustrySector'] = LabelEncoder().fit_transform(feature_df['IndustrySector']).astype(np.int8)
        feature_df['Gender'] = LabelEncoder().fit_transform(feature_df['Gender']).astype(np.int8)
        feature_df['EmploymentType'] = LabelEncoder().fit_transform(feature_df['EmploymentType']).astype(np.int8)
        feature_df['CriticalRisk'] = LabelEncoder().fit_transform(feature_df['CriticalRisk']).astype(np.int8)
        feature_df['Weekday'] = LabelEncoder().fit_transform(feature_df['Weekday']).astype(np.int8)
        feature_df.drop(['Description', 'Description_cleaned'], axis=1, inplace=True)
        print(feature_df)



    except Exception as e:
        print(e)

    pew = [[0,
           0,
           0,
           1,
           1,
           1,
           14,
           2016,
           4,
           22,
           0,
           0.3672087312021787,
           0.0,
           0.0,
           0.3952824458555833,
           0.5587210688132421,
           0.0,
           0.27817389046255353,
           0.0,
           0.0,
           0.27467596376076575,
           0.32765826250681374,
           0.3695304691084892,
           0.0,
           0.0,
           0.0,
           0.0,
           0.0,
           0.0,
           0.0,
           0.0,
           0.0,
           0.5678517154144366,
           0.5921952257695928,
           0.5717073061248936,
           0.0,
           0.0,
           0.0,
           0.0,
           0.0,
           0.0,
           0.0,
           0.0,
           0.0,
           0.0,
           0.0,
           0.0]]
    try:
        clf2 = joblib.load('RandomForestClassifier.sav')
        result = clf2.predict(pew).tolist()
        print(result)
        data["data"] = result
    except Exception as e:
        print(e)

    return JsonResponse(data, safe=False)
