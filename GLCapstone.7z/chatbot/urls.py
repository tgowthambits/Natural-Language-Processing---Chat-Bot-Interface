from django.contrib import admin
from django.urls import path


from chatbot.views import data_cleaning, BasicUploadView, model_form_upload, simple_upload, run_eda
from django.conf import settings
from django.conf.urls import url, include
from django.conf.urls.static import static


urlpatterns = [
    # path('', data_cleaning, name='data_clean'),
    path('simple_upload', simple_upload, name='simple_upload'),
    path('', model_form_upload, name='model_form_upload'),
    path('run_eda', run_eda, name='run_eda'),
    path('basic-upload/', BasicUploadView.as_view(), name='basic_upload'),

    path('api/', include('chatbot.API.api_urls'))
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
